long populate_mass_function(char *, double, double, float **);
